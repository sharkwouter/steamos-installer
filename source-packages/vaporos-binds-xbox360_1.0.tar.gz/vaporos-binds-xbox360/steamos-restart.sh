#!/bin/bash
killall steam
