#!/bin/bash
pkill steam
